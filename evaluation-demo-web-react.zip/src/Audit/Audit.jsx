import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { userActions } from '../_actions';

import { Navbar, Nav } from 'react-bootstrap';
class Auditpage extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
            searchedValue:''  
        };
       this.onSearch = this.onSearch.bind(this);
    }
    componentDidMount() {
        console.log(this.props,"898")
        this.props.getUsers();
        // const filteredItems = this.props.items.filter((item) => item.id.includes(this.state.searchedValue));

    }
    onSearch(event)  {
        this.setState({ 
            searchedValue: event.target.value });
    }

    formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
            // hours = d.getTime();

    
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
        
    
        return [day, month, year].join('/');
    }

    handleDeleteUser(id) {
        return (e) => this.props.deleteUser(id);
    }

    render() {
        const { user, users } = this.props;

        // const filteredItems = this.props.users.items.filter((item) => item.id.includes(this.state.searchedValue));

        return (
            <div>
                <Navbar bg="dark" variant="dark">
                    <Navbar.Brand ></Navbar.Brand>
                    <Nav className="mr-auto">
                        <Nav.Link ><Link to="/">Home</Link></Nav.Link>
                        <Nav.Link href="#features">Auditor</Nav.Link>
                        <Nav.Link> <Link to="/login">Logout</Link></Nav.Link>
                    </Nav>
                </Navbar>
                <div className="col-md-6 col-md-offset-3">

                    <h1>Hi {user.firstName}!</h1>
                    <p>You're logged in with React!!</p>
                    <h3>All login audit :</h3>
                    {users.loading && <em>Loading users...</em>}
                    {users.error && <span className="text-danger">ERROR: {users.error}</span>}
                    <table border="1">
                    <tr>
                        <th>ID</th>
                        <th>role</th>
                        <th>Createddate</th>
                        <th>Name</th>
                        <th>Delete</th>
                    </tr>
                    {users.items &&
                        users.items.sort().map(user =>
                        <tr>
                            <td>{user.id}</td>
                            <td>{user.role}</td>
                            <td>{this.formatDate(user.createdDate)}</td>
                            <td>{user.firstName+' '+user.lastName}</td>
                            <td> 
                                {
                                 user.deleting ? <em> - Deleting...</em>
                                 : user.deleteError ? <span className="text-danger"> - ERROR: {user.deleteError}</span>
                                : <span> - <a onClick={this.handleDeleteUser(user.id)}>Delete</a></span>
                                }
                            </td>
                        </tr>
                        )
                    }
                 </table>

                </div>

            </div>
        );
    }
}

function mapState(state) {
    const { users, authentication } = state;
    const { user } = authentication;
    return { user, users };
}

const actionCreators = {
    getUsers: userActions.getAll,
    deleteUser: userActions.delete
}

const connectedAuditPage = connect(mapState, actionCreators)(Auditpage);
export { connectedAuditPage as Auditpage };